from flask import abort,render_template,redirect
from flask import jsonify
from flask import request

from Backend import app
from .models import User, donars, bloodbank,bloodbankSchema,city,citySchema,recipients,donorsSchema,recipientsSchema, db
blood_bank_schema = bloodbankSchema(many=True)
doner_schema= donorsSchema(many=True)
recipient_schema= recipientsSchema(many=True)
city_schema = citySchema(many=True)
db.init_app(app)


@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        email = request.form['email']
        password = request.form['password']
        result = User.query.filter(User.email == email).first()
        if result:
            if result.password==password:        
                return {"status":"Ok"}  
        return {"status":"Fail"}  

@app.route("/signup",methods=["GET","POST"])
def signup():
    if request.method=="POST":
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        user_item = User(name,email,password)
        db.session.add(user_item)
        db.session.commit()
        return {"status":"Ok"}    

@app.route("/homedata",methods=["GET","POST"])
def homedata():
    city_name = []
    bldData=bloodbank.query.order_by("cityid").all()
    for i in bldData:
        cityid = i.cityid
        city_item = city.query.filter(city.cityid==cityid).first()
        cityname = city_item.cityName
        city_name.append(cityname)
    bldData = blood_bank_schema.dump(bldData)
    return {"data":bldData,"city":city_name}
 

@app.route("/detailsdata",methods=["POST"])
def detailsdata():
    donorlist=donars.query.all()
    donordata = doner_schema.dump(donorlist)
    recplist=recipients.query.all()
    recpdata= recipient_schema.dump(recplist)
    return {"data1":donordata,"data2":recpdata}
    
@app.route("/getcities", methods=["GET","POST"])
def getcities():
    cities = city.query.all()
    print(cities)
    cities = city_schema.dump(cities)
    for i in range(len(cities)):
        del cities[i]["city"]
    print(cities)
    return {"data":cities}

@app.route("/saveDonor", methods=["POST"])
def saveDonor():
    if request.method=="POST":
        nam = request.form["name"]
        cty = request.form["city"]
        uni = request.form["units"]
        bgp = request.form["bldgrp"]
        dod = request.form["dod"]
        donor = donars(dname=nam,dgroup=bgp,ddate=dod,city=cty,dunits=uni)
        db.session.add(donor)
        bldbank = bloodbank.query.filter_by(cityid=cty).first()
        if bgp=="AP":
            newUnits= bldbank.ap
            bldbank.ap = int(newUnits)+int(uni)
        if bgp=="AN":
            newUnits= bldbank.an
            bldbank.an = int(newUnits)+int(uni) 
        if bgp=="BP":
            newUnits= bldbank.bp
            bldbank.bp = int(newUnits)+int(uni)        
        if bgp=="BN":
            newUnits= bldbank.bn
            bldbank.bn = int(newUnits)+int(uni)        
        if bgp=="ABP":
            newUnits= bldbank.abp
            bldbank.abp = int(newUnits)+int(uni)
        if bgp=="ABN":
            newUnits= bldbank.abn
            bldbank.abn = int(newUnits)+int(uni) 
        if bgp=="OP":
            newUnits= bldbank.op
            bldbank.op = int(newUnits)+int(uni)        
        if bgp=="ONEG":
            newUnits= bldbank.oneg
            bldbank.oneg = int(newUnits)+int(uni)         
        db.session.commit()
        
        bldData=bloodbank.query.all()
        return {"status":"Ok"}  
        

@app.route("/saveRecp", methods=["POST"])
def saveRecp():
    if request.method=="POST":
        nam = request.form["name"]
        phn = request.form["phone"]
        cty = request.form["city"]
        uni = int(request.form["units"])
        bgp = request.form["bldgrp"]
        dor = request.form["dor"]
        dod = request.form["dod"]
        recp = recipients(rname=nam,bldgroup=bgp,rphone=phn,reqdate=dor, deldate=dod,rcity=cty,runits=uni)
        db.session.add(recp)
        bldbank = bloodbank.query.filter_by(cityid=cty).first()
        
        if bgp=="AP":
            newUnits= bldbank.ap
            if (newUnits>uni):
                bldbank.ap = int(newUnits)-int(uni)
            
        if bgp=="AN":
            newUnits= bldbank.an
            if (newUnits>uni):
                bldbank.an = int(newUnits)-int(uni)
            
        if bgp=="BP":
            newUnits= bldbank.bp
            if (newUnits>uni):
                bldbank.bp = int(newUnits)-int(uni)
                
        if bgp=="BN":
            newUnits= bldbank.bn
            if (newUnits>uni):
                bldbank.bn = int(newUnits)-int(uni)
                
        if bgp=="ABP":
            newUnits= bldbank.abp
            if (newUnits>uni):
                bldbank.abp = int(newUnits)-int(uni)
        
        if bgp=="ABN":
            newUnits= bldbank.abn
            if (newUnits>uni):
                bldbank.abn = int(newUnits)-int(uni)
            
        if bgp=="OP":
            newUnits= bldbank.op
            if (newUnits>uni):
                bldbank.op = int(newUnits)-int(uni)
                
        if bgp=="ONEG":
            newUnits= bldbank.oneg
            if (newUnits>uni):
                bldbank.oneg = int(newUnits)-int(uni)
                
        db.session.commit()
        bldData=bloodbank.query.all()
        return {"status":"Ok"}  
