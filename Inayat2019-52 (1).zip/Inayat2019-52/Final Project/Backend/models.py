from flask_marshmallow import Marshmallow
from flask_sqlalchemy import SQLAlchemy
#from sqlalchemy import primary_keyConstraint

from Backend import app
db = SQLAlchemy(app)
ma = Marshmallow(app)

class User(db.Model):
    uid = db.Column(db.Integer, primary_key=True,autoincrement=True)
    name = db.Column(db.String(80))
    email = db.Column(db.String(80))
    password = db.Column(db.Text)
    def __init__(self,name,email,password):
        self.name = name
        self.email = email
        self.password = password
        
class UserSchema(ma.Schema):
    class Meta:
        fields = ('uid', 'name','email','password')

class donars(db.Model):
    did =db.Column(db.Integer(), primary_key=True)
    dname=db.Column(db.String(80), nullable=False)
    dgroup =db.Column(db.String(80), nullable=False)
    ddate =db.Column(db.Date, nullable=True)
    dunits = db.Column(db.Integer(), nullable=True)
    city=db.Column(db.String(80), nullable=True)
    def __init__(self,dname,dgroup,ddate,dunits,city):
        self.dname = dname
        self.dgroup=dgroup
        self.ddate=ddate
        self.dunits=dunits
        self.city=city

class donorsSchema(ma.Schema):
    class Meta:
        fields = ('did', 'dname', 'dgroup','ddate','dunits','city')
   
class recipients(db.Model):
    rid=db.Column(db.Integer(), primary_key=True) 
    rname=db.Column(db.String(80), nullable=False) 
    rphone=db.Column(db.String(70), nullable=False)
    bldgroup=db.Column(db.String(60), nullable=False)
    reqdate=db.Column(db.Date, nullable=True)
    deldate=db.Column(db.Date, nullable=True)
    runits = db.Column(db.Integer(), nullable=True)
    rcity=db.Column(db.String(60), nullable=True)
    def __init__(self,rname,rphone,bldgroup,reqdate,deldate,runits,rcity):
        self.rname = rname
        self.rphone=rphone
        self.bldgroup=bldgroup
        self.reqdate=reqdate
        self.deldate=deldate
        self.runits=runits
        self.rcity=rcity
        
class recipientsSchema(ma.Schema):
    class Meta:
        fields = ('rid', 'rname', 'rphone','bldgroup','reqdate','deldate','runits','rcity')
class city(db.Model):
    cityid = db.Column(db.Integer(), primary_key=True)
    cityName =db.Column(db.String(90), nullable=False)
    city = db.relationship("bloodbank", backref="city", lazy=True)
    def __init__(self, cityid,cityName,city):
        self.cityid=cityid
        self.cityName=cityName
        self.city=city
class citySchema(ma.Schema):
    class Meta:
        fields = ('cityid', 'cityName','city')
class bloodbank(db.Model):
    bid = db.Column(db.Integer(), primary_key=True)
    ap = db.Column(db.Integer(), nullable=False)
    an =db.Column(db.Integer(), nullable=False)
    bp =db.Column(db.Integer(), nullable=False)
    bn =db.Column(db.Integer(), nullable=True)
    abn = db.Column(db.Integer(), nullable=True)
    abp = db.Column(db.Integer(), nullable=True)
    op = db.Column(db.Integer(), nullable=True)
    oneg = db.Column(db.Integer(), nullable=True)
    cityid = db.Column(db.Integer(), db.ForeignKey("city.cityid"), nullable=False)
    def __init__(self, bid,ap,an,bp,bn,abn,abp,op,oneg,cityid):
        self.bid=bid
        self.ap=ap
        self.an=an
        self.bp=bp
        self.bn=bn
        self.abn=abn
        self.abp=abp
        self.op=op
        self.oneg=oneg
        self.cityid=cityid
class bloodbankSchema(ma.Schema):
    class Meta:
        fields = ('bid', 'ap','an','bp', 'bn','abn','abp', 'op','oneg','cityid')

db.create_all()
