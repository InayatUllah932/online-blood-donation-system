import os

from flask import Flask
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://sql6496128:3mlnEf6qcv@sql6.freemysqlhosting.net/sql6496128'

from Backend import models
from Backend import views
